
import React from 'react';
function App() {
  return (
    <div className="App">
      <h1>Welcome to PanoDataVu MVP</h1>
      <p>Policy creation engine coming soon.</p>
    </div>
  );
}
export default App;
