
// NGUYEN_CPPA
// Express server for handling CSV uploads and policy creation

const express = require('express');
const app = express();
const port = 5000;

app.get('/', (req, res) => {
  res.send('Backend API for PanoDataVu MVP');
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
